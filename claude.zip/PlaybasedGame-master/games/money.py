import random
import time
import uuid


class MoneyGame:
    def __init__(self, mode):
        self.mode = mode
        self.session_id = str(uuid.uuid4())

        # =====================================================
        # GAME SETTINGS
        # =====================================================

        self.total_questions = 10
        self.question_number = 1
        self.score = 0

        self.question = ""
        self.correct_answer = 0

        self.user_answer = 0
        self.selected_money = []

        self.start_time = 0
        self.answer_time = 0
        self.total_time = 0

        self.finished = False

        # =====================================================
        # MONEY BUTTONS
        # =====================================================

        # ONLY 4 physical buttons
        self.denominations = [1, 5, 10, 20]

        # Maximum amount that can be created
        self.max_amount = 50

        # =====================================================
        # ADAPTIVE DIFFICULTY
        # =====================================================

        # 1 = Easy
        # 2 = Medium
        # 3 = Hard
        self.difficulty = 1

        # Used to determine when difficulty should increase
        self.correct_streak = 0
        self.wrong_streak = 0

        # Time threshold for a "fast" answer
        self.fast_time = 5

        # =====================================================
        # ITEMS
        # =====================================================

        self.items = [
            ("pencil", 5),
            ("pencil", 7),
            ("eraser", 3),
            ("ruler", 7),
            ("notebook", 15),
            ("notebook", 20),
            ("notebook", 25),
            ("juice", 10),
            ("juice", 12),
            ("bread", 15),
            ("snack", 12),
            ("snack", 15),
            ("candy", 3),
            ("toy", 20),
            ("toy", 35),
            ("toy", 36),
            ("toy", 40),
            ("ball", 25),
            ("ball", 27),
            ("ball", 30),
            ("book", 35)
        ]

        # =====================================================
        # GENERATE FIRST QUESTION
        # =====================================================

        self.generate_question()

    # =========================================================
    # GENERATE QUESTION
    # =========================================================

    def generate_question(self):

        # Reset answer
        self.selected_money = []
        self.user_answer = 0

        # Start timer
        self.start_time = time.time()

        # =====================================================
        # 1. TOTAL COST
        # =====================================================

        if self.mode == "total":

            if self.difficulty == 1:

                # -----------------------------
                # EASY
                # -----------------------------

                item1, price1 = random.choice([
                    ("pencil", 5),
                    ("eraser", 3),
                    ("juice", 10),
                    ("candy", 3)
                ])

                item2, price2 = random.choice([
                    ("pencil", 5),
                    ("juice", 10),
                    ("bread", 15)
                ])

            elif self.difficulty == 2:

                # -----------------------------
                # MEDIUM
                # -----------------------------

                item1, price1 = random.choice([
                    ("pencil", 7),
                    ("ruler", 7),
                    ("notebook", 15),
                    ("snack", 12)
                ])

                item2, price2 = random.choice([
                    ("notebook", 15),
                    ("bread", 15),
                    ("toy", 20),
                    ("ball", 25)
                ])

            else:

                # -----------------------------
                # HARD
                # -----------------------------

                item1, price1 = random.choice([
                    ("toy", 27),
                    ("ball", 27),
                    ("toy", 35),
                    ("book", 35)
                ])

                item2, price2 = random.choice([
                    ("toy", 20),
                    ("ball", 25),
                    ("toy", 36),
                    ("bread", 15)
                ])

            # Make sure total does not exceed ₱50
            while price1 + price2 > self.max_amount:

                if self.difficulty == 1:

                    item2, price2 = random.choice([
                        ("pencil", 5),
                        ("juice", 10),
                        ("bread", 15)
                    ])

                elif self.difficulty == 2:

                    item2, price2 = random.choice([
                        ("notebook", 15),
                        ("bread", 15),
                        ("toy", 20)
                    ])

                else:

                    item2, price2 = random.choice([
                        ("bread", 15),
                        ("toy", 20),
                        ("ball", 25)
                    ])

            self.item1 = item1
            self.item2 = item2

            self.price1 = price1
            self.price2 = price2

            self.correct_answer = price1 + price2

            self.question = (
                f"You want to buy a {item1} for ₱{price1} "
                f"and a {item2} for ₱{price2}. "
                f"What is the total cost?"
            )

        # =====================================================
        # 2. CHANGE
        # =====================================================

        elif self.mode == "change":

            if self.difficulty == 1:

                # -----------------------------
                # EASY
                # -----------------------------

                item, price = random.choice([
                    ("pencil", 5),
                    ("eraser", 3),
                    ("juice", 10),
                    ("candy", 3)
                ])

                money_given = random.choice([
                    10,
                    20
                ])

            elif self.difficulty == 2:

                # -----------------------------
                # MEDIUM
                # -----------------------------

                item, price = random.choice([
                    ("pencil", 7),
                    ("ruler", 7),
                    ("notebook", 15),
                    ("bread", 15),
                    ("snack", 12)
                ])

                money_given = random.choice([
                    20,
                    50
                ])

            else:

                # -----------------------------
                # HARD
                # -----------------------------

                item, price = random.choice([
                    ("toy", 27),
                    ("ball", 27),
                    ("toy", 35),
                    ("book", 35),
                    ("toy", 36)
                ])

                money_given = 50

            # Make sure the customer gives enough money
            while money_given <= price:

                if self.difficulty == 1:

                    money_given = random.choice([
                        10,
                        20
                    ])

                elif self.difficulty == 2:

                    money_given = random.choice([
                        20,
                        50
                    ])

                else:

                    money_given = 50

            self.item = item
            self.price = price
            self.money_given = money_given

            self.correct_answer = money_given - price

            self.question = (
                f"A {item} costs ₱{price}. "
                f"You give the cashier ₱{money_given}. "
                f"How much change will you get?"
            )

        # =====================================================
        # 3. SAVINGS
        # =====================================================

        elif self.mode == "savings":

            if self.difficulty == 1:

                # -----------------------------
                # EASY
                # -----------------------------

                item, price = random.choice([
                    ("pencil", 5),
                    ("eraser", 3),
                    ("juice", 10)
                ])

                saving1 = random.choice([
                    1,
                    5
                ])

                saving2 = random.choice([
                    1,
                    5
                ])

            elif self.difficulty == 2:

                # -----------------------------
                # MEDIUM
                # -----------------------------

                item, price = random.choice([
                    ("notebook", 15),
                    ("bread", 15),
                    ("snack", 15),
                    ("toy", 20)
                ])

                saving1 = random.choice([
                    5,
                    10
                ])

                saving2 = random.choice([
                    5,
                    10
                ])

            else:

                # -----------------------------
                # HARD
                # -----------------------------

                item, price = random.choice([
                    ("toy", 35),
                    ("ball", 30),
                    ("book", 35),
                    ("toy", 40)
                ])

                saving1 = random.choice([
                    10,
                    15,
                    20
                ])

                saving2 = random.choice([
                    10,
                    15,
                    20
                ])

            saved = saving1 + saving2

            # Make sure savings do not exceed item price
            while saved > price:

                if self.difficulty == 1:

                    saving1 = random.choice([
                        1,
                        5
                    ])

                    saving2 = random.choice([
                        1,
                        5
                    ])

                elif self.difficulty == 2:

                    saving1 = random.choice([
                        5,
                        10
                    ])

                    saving2 = random.choice([
                        5,
                        10
                    ])

                else:

                    saving1 = random.choice([
                        10,
                        15,
                        20
                    ])

                    saving2 = random.choice([
                        10,
                        15,
                        20
                    ])

                saved = saving1 + saving2

            self.item = item
            self.item_price = price

            self.saving1 = saving1
            self.saving2 = saving2

            self.correct_answer = saved

            self.question = (
                f"You are saving for a {item} that costs ₱{price}. "
                f"You save ₱{saving1} today and ₱{saving2} tomorrow. "
                f"How much have you saved?"
            )

        # =====================================================
        # 4. MAKE THE AMOUNT
        # =====================================================

        elif self.mode == "make":

            if self.difficulty == 1:

                # -----------------------------
                # EASY
                # -----------------------------

                item, price = random.choice([
                    ("pencil", 5),
                    ("juice", 10)
                ])

            elif self.difficulty == 2:

                # -----------------------------
                # MEDIUM
                # -----------------------------

                item, price = random.choice([
                    ("notebook", 15),
                    ("bread", 15),
                    ("toy", 20),
                    ("ball", 25)
                ])

            else:

                # -----------------------------
                # HARD
                # -----------------------------

                item, price = random.choice([
                    ("toy", 27),
                    ("ball", 27),
                    ("toy", 36),
                    ("toy", 40),
                    ("book", 35)
                ])

            self.item = item
            self.item_price = price

            self.correct_answer = price

            self.question = (
                f"A {item} costs ₱{price}. "
                f"Use the money buttons to pay exactly ₱{price}."
            )

        # =====================================================
        # INVALID MODE
        # =====================================================

        else:

            self.correct_answer = 0

            self.question = (
                "Invalid money game mode."
            )

    # =========================================================
    # ADD MONEY
    # =========================================================

    def add_money(self, value):

        if self.finished:
            return

        # Only accept the four physical money buttons
        if value not in self.denominations:
            return

        # Never allow more than ₱50
        if self.user_answer + value > self.max_amount:
            return

        self.user_answer += value
        self.selected_money.append(value)

    # =========================================================
    # CLEAR ANSWER
    # =========================================================

    def clear_answer(self):

        if self.finished:
            return

        self.user_answer = 0
        self.selected_money = []

    # =========================================================
    # ADAPTIVE DIFFICULTY
    # =========================================================

    def update_difficulty(self, correct, answer_time):

        # =====================================================
        # CORRECT ANSWER
        # =====================================================

        if correct:

            self.correct_streak += 1
            self.wrong_streak = 0

            # Two fast correct answers in a row
            # means the student is ready for a harder question.
            if (
                self.correct_streak >= 2
                and answer_time <= self.fast_time
            ):

                self.difficulty += 1

                # Reset streak after increasing difficulty
                self.correct_streak = 0

        # =====================================================
        # WRONG ANSWER
        # =====================================================

        else:

            self.wrong_streak += 1
            self.correct_streak = 0

            # One wrong answer makes the next question easier.
            self.difficulty -= 1

        # =====================================================
        # KEEP DIFFICULTY BETWEEN 1 AND 3
        # =====================================================

        self.difficulty = max(
            1,
            min(3, self.difficulty)
        )

    # =========================================================
    # SUBMIT ANSWER
    # =========================================================

    def submit_answer(self):

        if self.finished:
            return None

        # Do not allow an empty answer
        if self.user_answer == 0:
            return None

        # Calculate answer time
        self.answer_time = (
            time.time() - self.start_time
        )

        # Add to total time
        self.total_time += self.answer_time

        # Check answer
        correct = (
            self.user_answer == self.correct_answer
        )

        # Update score
        if correct:
            self.score += 1

        # =====================================================
        # ADAPTIVE DIFFICULTY & DATABASE PREP
        # =====================================================

        # Store the difficulty & question before it changes
        answered_difficulty = self.difficulty
        question_text = self.question

        self.update_difficulty(
            correct,
            self.answer_time
        )

        next_difficulty = self.difficulty

        # Determine Adaptation and Reason for the Database
        if next_difficulty > answered_difficulty:
            adaptation = "INCREASE"
            reason = "Fast and correct answer"
        elif next_difficulty < answered_difficulty:
            adaptation = "DECREASE"
            reason = "Incorrect answer"
        else:
            adaptation = "STAY"
            reason = "Normal progress"

        # =====================================================
        # RESULT
        # =====================================================

        result = {
            "correct": correct,
            "user_answer": self.user_answer,
            "correct_answer": self.correct_answer,
            "time": self.answer_time,
            
            # Database tracking fields
            "difficulty": answered_difficulty,
            "next_difficulty": next_difficulty,
            "adaptation": adaptation,
            "decision_reason": reason,
            "question": question_text,
            "question_number": self.question_number,
            "score": self.score
        }

        # Move to next question
        self.question_number += 1

        # =====================================================
        # FINISHED
        # =====================================================

        if self.question_number > self.total_questions:

            self.finished = True

        # =====================================================
        # NEXT QUESTION
        # =====================================================

        else:

            self.generate_question()

        return result
    # =========================================================
    # AVERAGE TIME
    # =========================================================

    def average_time(self):

        answered = self.question_number - 1

        if answered <= 0:
            return 0

        return self.total_time / answered

    # =========================================================
    # GET DIFFICULTY NAME
    # =========================================================

    def get_difficulty_name(self):

        if self.difficulty == 1:
            return "Easy"

        elif self.difficulty == 2:
            return "Medium"

        elif self.difficulty == 3:
            return "Hard"

        return "Unknown"

    # =========================================================
    # GET GAME SUMMARY
    # =========================================================

    def get_summary(self):

        return {
            "mode": self.mode,
            "score": self.score,
            "total_questions": self.total_questions,
            "average_time": self.average_time(),
            "difficulty": self.difficulty,
            "difficulty_name": self.get_difficulty_name(),
            "finished": self.finished
        }
